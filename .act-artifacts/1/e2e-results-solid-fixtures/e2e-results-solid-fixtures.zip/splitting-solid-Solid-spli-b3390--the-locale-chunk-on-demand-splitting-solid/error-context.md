# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - button "English" [ref=e5]
    - button "日本語" [active] [ref=e6]
  - paragraph
  - heading [level=1]
  - paragraph [ref=e7]: Hello, World!
  - paragraph [ref=e8]: 2 items
  - paragraph [ref=e9]: Administrator
```