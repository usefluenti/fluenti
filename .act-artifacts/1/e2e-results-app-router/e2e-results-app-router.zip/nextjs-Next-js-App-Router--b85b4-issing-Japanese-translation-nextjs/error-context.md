# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - navigation [ref=e3]:
      - link "ホーム" [ref=e4] [cursor=pointer]:
        - /url: /
      - link "概要" [ref=e5] [cursor=pointer]:
        - /url: /about
      - link "複数形" [ref=e6] [cursor=pointer]:
        - /url: /plurals
      - link "RSC" [ref=e7] [cursor=pointer]:
        - /url: /rsc
      - link "メタデータ" [ref=e8] [cursor=pointer]:
        - /url: /metadata
      - link "ストリーミング" [ref=e9] [cursor=pointer]:
        - /url: /streaming
      - link "アクション" [ref=e10] [cursor=pointer]:
        - /url: /server-action
      - link "リッチテキスト" [ref=e11] [cursor=pointer]:
        - /url: /richtext
      - link "RSC Rich Text" [ref=e12] [cursor=pointer]:
        - /url: /rsc-richtext
      - link "フォールバック" [ref=e13] [cursor=pointer]:
        - /url: /fallback
    - generic [ref=e14]:
      - button "English" [ref=e15]
      - button "日本語" [active] [ref=e16]
      - button "العربية" [ref=e17]
  - generic [ref=e18]:
    - heading "フォールバックデモ" [level=1] [ref=e19]
    - paragraph [ref=e20]: "Current: ja"
    - paragraph [ref=e21]: m47gv3
    - paragraph [ref=e22]: Fluenti へようこそ
  - alert [ref=e23]
```